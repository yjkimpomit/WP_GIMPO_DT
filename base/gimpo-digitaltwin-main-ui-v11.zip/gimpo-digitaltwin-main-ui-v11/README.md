# 김포열병합 디지털트윈 메인 UI v11

## 변경 요약
- 카드 헤더와 카드 본문을 분리했습니다.
- 내용이 넘치는 경우 카드 전체가 아니라 `.panel-body`만 내부 스크롤됩니다.
- 스크롤바가 나타날 때 내용 폭이 밀려 보이지 않도록 `scrollbar-gutter: stable`과 투명 scrollbar thumb 방식을 적용했습니다.
- 기본 상태에서는 스크롤바 thumb가 보이지 않고, hover/focus 상태에서만 6px 스크롤바가 보입니다.
- `GENi 정비/TM 통계`, `실시간 알람`, `Tag 연계 콘텐츠`, `선택 설비 정보 패널` 모두 동일한 내부 스크롤 정책을 적용했습니다.

## 핵심 CSS 원칙
- `.overlay-panel`: 레이아웃 컨테이너, `overflow:hidden`
- `.panel-head`: 고정 헤더
- `.panel-body.custom-scroll`: 실제 스크롤 영역
- `.custom-scroll`: scrollbar 공간을 항상 확보하되 thumb는 hover 시에만 표시
