const navItems = document.querySelectorAll(".nav-item");
const screens = document.querySelectorAll(".screen-panel");
const searchInput = document.getElementById("globalSearch");
const specDialog = document.getElementById("specDialog");
const openSpec = document.getElementById("openSpec");

function activateScreen(id) {
  navItems.forEach((item) => {
    item.classList.toggle("is-active", item.dataset.screen === id);
  });
  screens.forEach((screen) => {
    screen.classList.toggle("is-active", screen.id === id);
  });
}

navItems.forEach((item) => {
  item.addEventListener("click", () => activateScreen(item.dataset.screen));
});

document.querySelectorAll(".segmented button").forEach((button) => {
  button.addEventListener("click", (event) => {
    const group = event.currentTarget.closest(".segmented");
    group.querySelectorAll("button").forEach((el) => el.classList.remove("is-selected"));
    event.currentTarget.classList.add("is-selected");
  });
});

openSpec?.addEventListener("click", () => {
  if (typeof specDialog.showModal === "function") {
    specDialog.showModal();
  }
});

searchInput?.addEventListener("keydown", (event) => {
  if (event.key !== "Enter") return;
  event.preventDefault();

  const keyword = searchInput.value.trim();
  if (!keyword) return;

  const normalized = keyword.toLowerCase();
  const target =
    normalized.includes("도면") || normalized.includes("pid") ? "drawing" :
    normalized.includes("ar") || normalized.includes("파노라마") ? "panorama" :
    normalized.includes("안전") || normalized.includes("cctv") ? "safety" :
    normalized.includes("관리") || normalized.includes("권한") ? "admin" :
    normalized.includes("3d") || normalized.includes("모델") ? "viewer3d" :
    "dashboard";

  activateScreen(target);
});

document.querySelectorAll(".pid-node, .pano-tag").forEach((node) => {
  node.addEventListener("click", () => {
    node.animate(
      [
        { transform: "scale(1)" },
        { transform: "scale(1.12)" },
        { transform: "scale(1)" }
      ],
      { duration: 260, easing: "ease-out" }
    );
  });
});
