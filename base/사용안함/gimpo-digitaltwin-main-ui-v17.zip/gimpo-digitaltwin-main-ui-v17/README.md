# 김포열병합 디지털트윈 플랫폼 UI v17 - Light Neutral

## 변경 요약

- 메인 화면과 도면 화면을 모두 라이트모드 + 뉴트럴톤으로 변경
- 도면 원본/도면 캔버스가 흰색인 점을 기준으로 주변 UI를 밝은 그레이 톤으로 보정
- 메인 화면은 완전한 화이트가 아니라 `#eef1f4`, `#f8fafc`, `#ffffff` 중심의 저채도 뉴트럴 팔레트 적용
- 카드, 서랍, 헤더, 팝업, 스크롤바, 트리 메뉴의 대비를 라이트 환경에 맞게 조정
- 기존 기능 구성 유지: GasPED / DCAT / PreVision, AR 점검, 설비 Tree, 좌우 패널, 카드별 내부 스크롤

## 파일 구성

- `index.html` : 메인 화면 Light Neutral
- `drawing-neutral.html` : 도면 화면 Light Neutral
- `styles.css` : 메인 공통 스타일 및 v17 라이트 뉴트럴 오버라이드
- `app.js` : 상호작용 스크립트
- `sitemap.md` : 사이트맵
