# 김포DT Light Neutral Graphite 컬러 제안

## 전략
- iPOS와의 호환성: 메뉴 구조, 설비 Tree, Tag 연계, 카드/팝업 조작 방식 유지
- 김포DT 차별화: Light Neutral Graphite 기반 컬러, Turbine Blue, Thermal Amber, Safety Teal 적용
- 도면 화면은 흰색 캔버스를 유지하고 주변 UI만 뉴트럴 그레이로 제어

## 핵심 토큰

| Token | Hex | 용도 |
|---|---:|---|
| `--bg-app` | `#E8ECEF` | 전체 앱 배경 |
| `--bg-canvas` | `#F2F4F6` | 중앙 작업 영역 |
| `--surface-1` | `#FFFFFF` | 기본 카드 |
| `--surface-2` | `#F7F9FA` | 카드 내부/입력 |
| `--surface-3` | `#EEF2F5` | hover/Tree 선택 |
| `--text-primary` | `#17202A` | 주요 텍스트 |
| `--text-secondary` | `#4B5967` | 보조 텍스트 |
| `--border-subtle` | `#DDE3E8` | 카드 라인 |
| `--primary-600` | `#16699F` | Turbine Blue / Active |
| `--thermal-500` | `#D98913` | 열병합/연소/주의 |
| `--safety-500` | `#178E86` | AR/CCTV/안전 |
| `--danger-500` | `#C92A2A` | Red-Tag/위험 |

## 적용 원칙
- 구조와 크기는 기존 다크모드와 동일하게 유지한다.
- 라이트모드는 컬러 토큰만 교체한다.
- 도면 캔버스는 흰색으로 유지한다.
- 헤더/서랍/카드는 완전한 흰색보다 뉴트럴 그레이 대비를 사용한다.
