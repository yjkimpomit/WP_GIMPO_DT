# 김포열병합 디지털트윈 플랫폼 UI v21

## 목적
이 버전은 iPOS와의 호환성/통일성을 유지하면서 김포DT만의 차별화 컬러를 적용한 `Light Neutral Graphite` 제안 버전입니다.

## 반영사항
- 메인 화면 `index.html`에 Light Neutral Graphite 컬러 적용
- 도면 화면 `drawing-neutral.html`에도 동일한 라이트 뉴트럴 톤 적용
- 구조/크기/메뉴 간격은 기존 다크모드 기준 유지
- 컬러만 Turbine Blue, Thermal Amber, Safety Teal, Red-Tag 체계로 분리
- `color-system.md`와 `tokens-light-neutral-graphite.css` 포함

## 파일
- `index.html`
- `drawing-neutral.html`
- `styles.css`
- `app.js`
- `sitemap.md`
- `color-system.md`
- `tokens-light-neutral-graphite.css`
