# 김포열병합 디지털트윈 플랫폼 UI v15

## 변경사항
- `Tag 연계 콘텐츠`에 두케어 솔루션 3종을 분리 반영했습니다.
  - GasPED: 가스터빈 성능진단
  - DCAT: 연소기 자동튜닝
  - PreVision: 플랜트 운전상태 감시
- `Selected Asset Panel > 운전·성능` 탭에 두케어 요약 상태를 추가했습니다.
- GasPED / DCAT / PreVision 클릭 시 각 솔루션별 상세 팝업이 열립니다.
- 기존 구조 유지:
  - dashboard-layer는 grid가 아닌 좌/우 rail flex 구조
  - 전체틀 스크롤 없음
  - 카드별 내부 스크롤
  - 좌측 GENi 통계 상단 2칼럼
  - 우측 주요 운영 현황/Tag 연계 콘텐츠는 콘텐츠 높이 기준
  - 서랍 설비구조 Tree 여닫기 아이콘 유지

## 파일 구성
- index.html
- styles.css
- app.js
- README.md
