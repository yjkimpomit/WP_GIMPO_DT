# 김포열병합 디지털트윈 플랫폼 UI v16 - Drawing Neutral Gray 수정본

## 수정 반영

- `index.html`이 아니라 `drawing-neutral.html` 도면 화면을 그레이 뉴트럴 톤으로 별도 적용했습니다.
- 도면 화면은 전체적으로 중명도 Charcoal/Neutral Gray 기반으로 구성했습니다.
- 도면 목록, 중앙 Embedded Drawing Viewer, 우측 Tag 연계 정보 패널을 독립 화면으로 구성했습니다.
- P&ID / DCS / OWS / 전기 단선도 / 소방 Plan 도면 목록 예시를 포함했습니다.
- 중앙 도면 뷰어에는 Zoom, Pan, Highlight, Selection 툴바와 Tag 하이라이트 예시를 반영했습니다.
- 우측 패널에는 선택 Tag 기준 3D 모델, 운전정보, GENi, 파노라마 연계 버튼을 배치했습니다.

## 파일 구성

- `index.html` : 기존 메인 화면
- `drawing-neutral.html` : 그레이 뉴트럴 도면 화면
- `styles.css` : 메인 화면 스타일
- `app.js` : 메인 화면 인터랙션
- `sitemap.md`
